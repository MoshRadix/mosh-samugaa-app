﻿#SingleInstance Force
#Requires AutoHotkey v2.0

baseDir := A_ScriptDir
WageTemplateFile := baseDir "\Templates\WageMasakkathuTemplate.xlsx"
OTTemplateFile := baseDir "\Templates\OTTemplate.xlsx"
ContractTemplateFile := baseDir "\Templates\ContractMiskithuTemplate.xlsx"
OutputFolder := baseDir "\Output"
IniFile := baseDir "\Data.ini"

PH_Name := "{{NAME}}"
PH_ID := "{{ID}}"
PH_StartDate := "{{START_DATE}}"
PH_EndDate := "{{END_DATE}}"
PH_Year := "{{YEAR}}"
PH_Mosque := "{{MOSQUE}}"

ExcelProgID := "Excel.Application"
LastGeneratedFile := ""

; Divehi number mapping with actual Divehi characters
DivehiNumbers := Map(
    "0", "0", "1", "1", "2", "2", "3", "3", "4", "4",
    "5", "5", "6", "6", "7", "7", "8", "8", "9", "9"
)

; Divehi weekday names
DivehiWeekdays := Map(
    1, "ހޯމަ",      ; Monday
    2, "އަންގާރަ",  ; Tuesday
    3, "ބުދަ",      ; Wednesday
    4, "ބުރާސްފަތި", ; Thursday
    5, "ހުކުރު",    ; Friday
    6, "ހޮނިހިރު",  ; Saturday
    7, "އާދީއްތަ"   ; Sunday
)

; Divehi to English transliteration mapping
DivehiToEnglish := Map(
    "ހ", "h", "ށ", "sh", "ނ", "n", "ރ", "r", "ބ", "b",
    "ޅ", "lh", "ކ", "k", "އ", "a", "ވ", "v", "މ", "m",
    "ފ", "f", "ދ", "dh", "ތ", "th", "ލ", "l", "ގ", "g",
    "ޏ", "gn", "ސ", "s", "ޑ", "d", "ޒ", "z", "ޓ", "t",
    "ޔ", "y", "ޕ", "p", "ޖ", "j", "ޗ", "ch", "ޘ", "t",
    "ޙ", "h", "ޚ", "kh", "ޛ", "zh", "ޜ", "z", "ޝ", "sh",
    "ޞ", "s", "ޟ", "d", "ޠ", "t", "ޡ", "z", "ޢ", "a",
    "ޣ", "gh", "ޤ", "q", "ޥ", "w", "ަ", "a", "ާ", "aa",
    "ި", "i", "ީ", "ee", "ު", "u", "ޫ", "oo", "ެ", "e",
    "ޭ", "ey", "ޮ", "o", "ޯ", "oa", "ް", ""
)

; Divehi month names
DivehiMonths := Map(
    1, "ޖަނަވަރީ", 2, "ފެބްރުއަރީ", 3, "މާރޗް", 4, "އެޕްރީލް",
    5, "މެއި", 6, "ޖޫން", 7, "ޖުލައި", 8, "އޯގަސްޓް",
    9, "ސެޕްޓެމްބަރު", 10, "އޮކްޓޫބަރު", 11, "ނޮވެމްބަރު", 12, "ޑިސެމްބަރު"
)

; Function to convert numbers to Divehi digits
NumberToDivehi(num) {
    global DivehiNumbers
    numStr := num
    result := ""
    loop parse, numStr {
        digit := A_LoopField
        result .= DivehiNumbers.Has(digit) ? DivehiNumbers[digit] : digit
    }
    return result
}

; Function to get Divehi weekday name
GetDivehiWeekday(dateStr) {
    global DivehiWeekdays
    if !RegExMatch(dateStr, "(\d{4})-(\d{2})-(\d{2})", &match)
        return ""

    year := Integer(match[1])
    month := Integer(match[2])
    day := Integer(match[3])

    ; Using Tomohiko Sakamoto's algorithm
    static t := [0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4]

    if (month < 3)
        year -= 1

    ; Returns: 0=Sunday, 1=Monday, 2=Tuesday, 3=Wednesday, 4=Thursday, 5=Friday, 6=Saturday
    weekdayNum := Mod(year + Floor(year / 4) - Floor(year / 100) + Floor(year / 400) + t[month] + day, 7)

    ; Convert to our weekday numbering (1=Monday, 7=Sunday)
    switch weekdayNum {
        case 1: weekdayNum := 1  ; Monday
        case 2: weekdayNum := 2  ; Tuesday
        case 3: weekdayNum := 3  ; Wednesday
        case 4: weekdayNum := 4  ; Thursday
        case 5: weekdayNum := 5  ; Friday
        case 6: weekdayNum := 6  ; Saturday
        case 0: weekdayNum := 7  ; Sunday
    }

    return DivehiWeekdays.Has(weekdayNum) ? DivehiWeekdays[weekdayNum] : ""
}

; Helper function to check leap year
IsLeapYear(year) {
    return (Mod(year, 4) = 0 && (Mod(year, 100) != 0 || Mod(year, 400) = 0))
}

; Function to format date as dd-M
FormatDateAsDayMonth(dateStr) {
    global DivehiMonths
    if !RegExMatch(dateStr, "(\d{4})-(\d{2})-(\d{2})", &match)
        return dateStr

    day := Integer(match[3])
    month := Integer(match[2])

    divehiDay := NumberToDivehi(day)
    divehiMonth := DivehiMonths.Has(month) ? DivehiMonths[month] : month

    return divehiDay "-" divehiMonth
}

; Helper function to get days in a month
GetDaysInMonth(year, month) {
    if (month = 2) {
        if (Mod(year, 4) = 0 && (Mod(year, 100) != 0 || Mod(year, 400) = 0))
            return 29
        else
            return 28
    } else if (month = 4 || month = 6 || month = 9 || month = 11) {
        return 30
    } else {
        return 31
    }
}

; Function to get all dates between start and end dates
GetDateRange(startDate, endDate) {
    dates := []

    RegExMatch(startDate, "(\d{4})-(\d{2})-(\d{2})", &startMatch)
    startYear := Integer(startMatch[1])
    startMonth := Integer(startMatch[2])
    startDay := Integer(startMatch[3])

    RegExMatch(endDate, "(\d{4})-(\d{2})-(\d{2})", &endMatch)
    endYear := Integer(endMatch[1])
    endMonth := Integer(endMatch[2])
    endDay := Integer(endMatch[3])

    currentYear := startYear
    currentMonth := startMonth
    currentDay := startDay

    while (currentYear < endYear || (currentYear = endYear && (currentMonth < endMonth || (currentMonth = endMonth &&
        currentDay <= endDay)))) {
        dateStr := Format("{:04d}-{:02d}-{:02d}", currentYear, currentMonth, currentDay)
        dates.Push(dateStr)

        currentDay++
        daysInMonth := GetDaysInMonth(currentYear, currentMonth)

        if (currentDay > daysInMonth) {
            currentDay := 1
            currentMonth++
            if (currentMonth > 12) {
                currentMonth := 1
                currentYear++
            }
        }
    }
    return dates
}

; Function to populate date placeholders in Excel and clear unused ones
PopulateDatePlaceholders(xlWB, startDate, endDate) {
    dates := GetDateRange(startDate, endDate)
    numDates := dates.Length

    for index, dateStr in dates {
        formattedDate := FormatDateAsDayMonth(dateStr)
        weekday := GetDivehiWeekday(dateStr)
        placeholderDate := "{{d" index "}}"
        placeholderWeekday := "{{wd" index "}}"

        for sheet in xlWB.Worksheets {
            sheet.Cells.Replace(placeholderDate, formattedDate, 2)
            sheet.Cells.Replace(placeholderWeekday, weekday, 2)
        }
    }

    ; Clear remaining placeholders
    loop 31 {
        currentIdx := numDates + A_Index
        if (currentIdx > 31)
            break
        placeholderDate := "{{d" currentIdx "}}"
        placeholderWeekday := "{{wd" currentIdx "}}"
        for sheet in xlWB.Worksheets {
            sheet.Cells.Replace(placeholderDate, "", 2)
            sheet.Cells.Replace(placeholderWeekday, "", 2)
        }
    }
    return numDates
}

; Function to transliterate Divehi text to English
TransliterateDivehiToEnglish(divehiText) {
    global DivehiToEnglish
    if (divehiText = "")
        return ""

    result := ""
    skipNext := false

    loop parse, divehiText {
        char := A_LoopField
        currentIndex := A_Index

        if (skipNext) {
            skipNext := false
            continue
        }

        if (char = "އ" || char = "ޢ") {
            if (currentIndex < StrLen(divehiText)) {
                nextChar := SubStr(divehiText, currentIndex + 1, 1)
                if (nextChar = "ި" || nextChar = "ީ") {
                    result .= "i"
                    skipNext := true
                    continue
                }
            }

            result .= DivehiToEnglish.Has(char) ? DivehiToEnglish[char] : char

            if (currentIndex < StrLen(divehiText)) {
                nextChar := SubStr(divehiText, currentIndex + 1, 1)
                if (nextChar != "ި" && nextChar != "ީ") {
                    skipNext := true
                }
            }
            continue
        }
        result .= DivehiToEnglish.Has(char) ? DivehiToEnglish[char] : char
    }
    result := RegExReplace(result, "\s+", " ")
    return Trim(result)
}

; Function to format date in Divehi format
FormatDateToDivehi(dateStr) {
    global DivehiMonths
    if !RegExMatch(dateStr, "(\d{4})-(\d{2})-(\d{2})", &match)
        return dateStr

    year := match[1]
    month := Integer(match[2])
    day := Integer(match[3])

    divehiDay := NumberToDivehi(day)
    divehiYear := NumberToDivehi(year)
    divehiMonth := DivehiMonths.Has(month) ? DivehiMonths[month] : month

    return divehiDay " " divehiMonth " " divehiYear
}

GetStartDateDefault() {
    return A_YYYY . "-" . A_MM . "-16"
}

GetEndDateDefault() {
    nextMonth := A_MM + 1
    nextYear := A_YYYY
    if (nextMonth > 12) {
        nextMonth := 1
        nextYear := A_YYYY + 1
    }
    return nextYear . "-" . Format("{:02d}", nextMonth) . "-15"
}

SetDateTimeValue(dateTimeCtrl, dateValue) {
    if RegExMatch(dateValue, "(\d{4})-(\d{2})-(\d{2})", &match) {
        st := Buffer(16)
        NumPut("UShort", Integer(match[1]), st, 0)
        NumPut("UShort", Integer(match[2]), st, 2)
        NumPut("UShort", 0, st, 4)
        NumPut("UShort", Integer(match[3]), st, 6)
        SendMessage(0x1002, 0, st, dateTimeCtrl.Hwnd)
        return true
    }
    return false
}

; Unicode-aware INI functions
UnicodeIniRead(filePath, section, key, defaultValue := "") {
    if !FileExist(filePath)
        return defaultValue
    content := FileRead(filePath, "UTF-16")
    if (content = "")
        return defaultValue
    sectionPattern := "`n[" section "]"
    sectionPos := InStr(content, sectionPattern)
    if (!sectionPos) {
        if (SubStr(content, 1, StrLen(section) + 2) = "[" section "]")
            sectionPos := 1
        else
            return defaultValue
    } else {
        sectionPos += 1
    }
    lineEnd := InStr(content, "`n", , sectionPos)
    if (!lineEnd)
        return defaultValue
    sectionStart := lineEnd + 1
    nextSection := InStr(content, "`n[", , sectionStart)
    sectionEnd := nextSection ? nextSection + 1 : StrLen(content) + 1
    sectionContent := SubStr(content, sectionStart, sectionEnd - sectionStart)
    keyPattern := key "="
    keyPos := InStr(sectionContent, keyPattern)
    if (keyPos = 0)
        return defaultValue
    valueStart := keyPos + StrLen(keyPattern)
    lineEnd := InStr(sectionContent, "`n", , valueStart)
    if (lineEnd = 0)
        lineEnd := StrLen(sectionContent) + 1
    value := SubStr(sectionContent, valueStart, lineEnd - valueStart)
    return Trim(value, " `t`r`n")
}

UnicodeIniWrite(filePath, section, key, value) {
    content := FileExist(filePath) ? FileRead(filePath, "UTF-16") : ""
    if (content = "")
        content := ""
    if (content != "" && SubStr(content, -1) != "`n")
        content .= "`n"
    sectionHeader := "[" section "]"
    sectionPos := (SubStr(content, 1, StrLen(sectionHeader)) = sectionHeader) ? 1 : InStr(content, "`n" sectionHeader)
    if (!sectionPos) {
        if (content != "")
            content .= "`n"
        content .= sectionHeader "`n" key "=" value "`n"
    } else {
        if (sectionPos != 1)
            sectionPos += 1
        lineEnd := InStr(content, "`n", , sectionPos)
        if (!lineEnd) {
            content .= "`n" key "=" value "`n"
        } else {
            sectionContentStart := lineEnd + 1
            nextSectionPos := InStr(content, "`n[", , sectionContentStart)
            sectionEnd := nextSectionPos ? nextSectionPos : StrLen(content) + 1
            sectionContent := SubStr(content, sectionContentStart, sectionEnd - sectionContentStart)
            keyPattern := key "="
            keyPos := InStr(sectionContent, keyPattern)
            if (keyPos = 0) {
                newSectionContent := sectionContent . (SubStr(sectionContent, -1) != "`n" ? "`n" : "") . key "=" value .
                "`n"
                content := SubStr(content, 1, sectionContentStart - 1) . newSectionContent . SubStr(content, sectionEnd
                )
            } else {
                valueStart := keyPos + StrLen(keyPattern)
                valueEnd := InStr(sectionContent, "`n", , valueStart)
                if (!valueEnd)
                    valueEnd := StrLen(sectionContent) + 1
                oldValue := SubStr(sectionContent, valueStart, valueEnd - valueStart)
                newSectionContent := StrReplace(sectionContent, key "=" oldValue, key "=" value)
                content := SubStr(content, 1, sectionContentStart - 1) . newSectionContent . SubStr(content, sectionEnd
                )
            }
        }
    }
    if (content != "" && SubStr(content, -1) != "`n")
        content .= "`n"
    FileDelete(filePath)
    FileAppend(content, filePath, "UTF-16")
}

LoadNamesFromIni() {
    global IniFile
    names := []
    if !FileExist(IniFile)
        return names
    content := FileRead(IniFile, "UTF-16")
    if (content = "")
        return names
    sectionPos := InStr(content, "[People]")
    if (!sectionPos)
        return names
    nextSectionPos := InStr(content, "`n[", , sectionPos + 8)
    nextSectionPos := nextSectionPos ? nextSectionPos : StrLen(content) + 1
    lineEnd := InStr(content, "`n", , sectionPos)
    lineEnd := lineEnd ? lineEnd : sectionPos
    sectionContent := SubStr(content, lineEnd + 1, nextSectionPos - lineEnd - 1)
    for line in StrSplit(sectionContent, "`n") {
        line := Trim(line, " `t`r")
        if (line = "" || SubStr(line, 1, 1) = ";")
            continue
        equalPos := InStr(line, "=")
        if (equalPos > 0) {
            name := Trim(SubStr(line, 1, equalPos - 1))
            if (name != "")
                names.Push(name)
        }
    }
    return names
}

LoadMosqueFromIni(name) {
    global IniFile
    if !FileExist(IniFile)
        return ""
    content := FileRead(IniFile, "UTF-16")
    if (content = "")
        return ""
    sectionPos := InStr(content, "[Mosques]")
    if (!sectionPos)
        return ""
    nextSectionPos := InStr(content, "`n[", , sectionPos + 9)
    nextSectionPos := nextSectionPos ? nextSectionPos : StrLen(content) + 1
    lineEnd := InStr(content, "`n", , sectionPos)
    lineEnd := lineEnd ? lineEnd : sectionPos
    sectionContent := SubStr(content, lineEnd + 1, nextSectionPos - lineEnd - 1)
    keyPattern := name "="
    keyPos := InStr(sectionContent, keyPattern)
    if (keyPos = 0)
        return ""
    valueStart := keyPos + StrLen(keyPattern)
    lineEnd := InStr(sectionContent, "`n", , valueStart)
    if (lineEnd = 0)
        lineEnd := StrLen(sectionContent) + 1
    value := SubStr(sectionContent, valueStart, lineEnd - valueStart)
    return Trim(value, " `t`r`n")
}

UnicodeIniWriteMosque(filePath, section, key, value) {
    content := FileExist(filePath) ? FileRead(filePath, "UTF-16") : ""
    if (content = "")
        content := ""
    if (content != "" && SubStr(content, -1) != "`n")
        content .= "`n"
    sectionHeader := "[" section "]"
    sectionPos := (SubStr(content, 1, StrLen(sectionHeader)) = sectionHeader) ? 1 : InStr(content, "`n" sectionHeader)
    if (!sectionPos) {
        if (content != "")
            content .= "`n"
        content .= sectionHeader "`n" key "=" value "`n"
    } else {
        if (sectionPos != 1)
            sectionPos += 1
        lineEnd := InStr(content, "`n", , sectionPos)
        if (!lineEnd) {
            content .= "`n" key "=" value "`n"
        } else {
            sectionContentStart := lineEnd + 1
            nextSectionPos := InStr(content, "`n[", , sectionContentStart)
            sectionEnd := nextSectionPos ? nextSectionPos : StrLen(content) + 1
            sectionContent := SubStr(content, sectionContentStart, sectionEnd - sectionContentStart)
            keyPattern := key "="
            keyPos := InStr(sectionContent, keyPattern)
            if (keyPos = 0) {
                newSectionContent := sectionContent . (SubStr(sectionContent, -1) != "`n" ? "`n" : "") . key "=" value .
                "`n"
                content := SubStr(content, 1, sectionContentStart - 1) . newSectionContent . SubStr(content, sectionEnd
                )
            } else {
                valueStart := keyPos + StrLen(keyPattern)
                valueEnd := InStr(sectionContent, "`n", , valueStart)
                if (!valueEnd)
                    valueEnd := StrLen(sectionContent) + 1
                oldValue := SubStr(sectionContent, valueStart, valueEnd - valueStart)
                newSectionContent := StrReplace(sectionContent, key "=" oldValue, key "=" value)
                content := SubStr(content, 1, sectionContentStart - 1) . newSectionContent . SubStr(content, sectionEnd
                )
            }
        }
    }
    if (content != "" && SubStr(content, -1) != "`n")
        content .= "`n"
    FileDelete(filePath)
    FileAppend(content, filePath, "UTF-16")
}

PrintExcelFile(filePath, printArea := "A1:P46") {
    global ExcelProgID
    if !FileExist(filePath) {
        MsgBox "File not found:`n" filePath, "Error", 48 + 0x40000
        return false
    }
    try {
        xlApp := ComObject(ExcelProgID)
        xlApp.Visible := False
        xlWB := xlApp.Workbooks.Open(filePath)
        ws := xlWB.Sheets(1)
        ws.PageSetup.PrintArea := printArea
        ws.PageSetup.PaperSize := 9
        ws.PageSetup.Orientation := 2
        ws.PageSetup.CenterHorizontally := True
        ws.PageSetup.CenterVertically := False
        ws.PrintOut(1, 2, 1, false)
        xlWB.Close(false)
        xlApp.Quit()
        return true
    } catch as err {
        try xlApp.Quit()
        MsgBox "Error printing file:`n" err.Message, "Error", 16 + 0x40000
        return false
    }
}

; Unified function to generate and print based on selection
GenerateAndPrint(btn, info) {
    global WageTemplateFile, OTTemplateFile, ContractTemplateFile, OutputFolder, IniFile, LastGeneratedFile
    global PH_Name, PH_ID, PH_StartDate, PH_EndDate, PH_Year, PH_Mosque, ExcelProgID

    gui := btn.Gui
    name := gui["Name"].Text
    id := gui["ID"].Text
    sheetType := gui["SheetType"].Text

    ; Local variables
    selectedTemplate := ""
    xlWB := ""
    xlApp := ""
    fileSuffix := ""
    printArea := "A1:P46"
    needsDates := false
    needsMosque := false
    needsDatePlaceholders := false
    start := ""
    end := ""
    divehiStartDate := ""
    divehiEndDate := ""
    divehiYear := ""
    mosqueName := ""
    englishName := ""
    safeName := ""
    outputFile := ""
    year := ""

    ; Get mosque name if available
    mosqueName := gui["Mosque"].Text
    if (sheetType = "Contract Miskithu Attendance" && mosqueName = "") {
        mosqueName := LoadMosqueFromIni(name)
        if (mosqueName != "") {
            gui["Mosque"].Text := mosqueName
        }
    }

    ; Validate inputs
    if (name = "" || id = "") {
        MsgBox "Please fill in Name and ID fields.", "Error", 48 + 0x40000
        return
    }

    if (sheetType = "Contract Miskithu Attendance" && mosqueName = "") {
        MsgBox "Please fill in Mosque Name for Contract Miskithu Attendance sheet.", "Error", 48 + 0x40000
        return
    }

    ; Determine which template to use
    if (sheetType = "Wage Attendance Sheet") {
        selectedTemplate := WageTemplateFile
        fileSuffix := "Wage Attendance"
        needsDates := true
        needsDatePlaceholders := false
    } else if (sheetType = "OT Sheet") {
        selectedTemplate := OTTemplateFile
        fileSuffix := "OT Sheet"
        needsDates := false
        needsDatePlaceholders := false
    } else if (sheetType = "Contract Miskithu Attendance") {
        selectedTemplate := ContractTemplateFile
        fileSuffix := "Contract Miskithu Attendance"
        needsDates := true
        needsMosque := true
        needsDatePlaceholders := true
    } else {
        MsgBox "Please select a sheet type.", "Error", 48 + 0x40000
        return
    }

    ; Validate template exists
    if !FileExist(selectedTemplate) {
        MsgBox "Template file not found:`n" selectedTemplate, "Error", 16 + 0x40000
        return
    }

    ; Get dates if needed
    if (needsDates) {
        start := GetDateString(gui, "Start1")
        end := GetDateString(gui, "End1")
        if (start = "" || end = "") {
            MsgBox "Please fill in date range.", "Error", 48 + 0x40000
            return
        }
        divehiStartDate := FormatDateToDivehi(start)
        divehiEndDate := FormatDateToDivehi(end)
        year := SubStr(start, 1, 4)
        divehiYear := NumberToDivehi(year)
    }

    ; Create output folder
    if !DirExist(OutputFolder)
        DirCreate(OutputFolder)

    ; Start Excel
    try {
        xlApp := ComObject(ExcelProgID)
    } catch {
        MsgBox "Could not start Excel.", "Error", 16 + 0x40000
        return
    }

    xlApp.Visible := False
    try {
        xlWB := xlApp.Workbooks.Open(selectedTemplate)
    } catch as err {
        MsgBox "Could not open template file:`n" selectedTemplate "`n`nError: " err.Message, "Error", 16 + 0x40000
        xlApp.Quit()
        return
    }

    ; Replace basic placeholders
    for sheet in xlWB.Worksheets {
        sheet.Cells.Replace(PH_Name, name, 2)
        sheet.Cells.Replace(PH_ID, id, 2)
        if (needsDates) {
            sheet.Cells.Replace(PH_StartDate, divehiStartDate " އިން " divehiEndDate, 2)
            sheet.Cells.Replace(PH_Year, divehiYear, 2)
        }
        if (needsMosque) {
            sheet.Cells.Replace(PH_Mosque, mosqueName, 2)
        }
    }

    ; Populate date placeholders for contract sheet
    if (needsDatePlaceholders && start != "" && end != "") {
        PopulateDatePlaceholders(xlWB, start, end)
    }

    ; Create filename
    englishName := TransliterateDivehiToEnglish(name)
    safeName := englishName = "" ? "Unknown" : englishName
    for badChar in ["\", "/", ":", "*", "?", "`"", "<", ">", "|"] {
        safeName := StrReplace(safeName, badChar, "-")
    }
    safeName := RegExReplace(safeName, "[^\w\s\-]", "")
    safeName := RegExReplace(safeName, "\s+", " ")
    safeName := Trim(safeName)

    if (needsDates) {
        outputFile := OutputFolder "\" safeName " - " start " to " end " - " fileSuffix ".xlsx"
    } else {
        currentDate := A_YYYY . "-" . A_MM . "-" . A_DD
        outputFile := OutputFolder "\" safeName " - " fileSuffix " - " currentDate ".xlsx"
    }

    ; Save the file and print automatically
    try {
        xlWB.SaveAs(outputFile)
        xlWB.Close(false)
        xlApp.Quit()
        LastGeneratedFile := outputFile

        if (needsMosque && mosqueName != "") {
            UnicodeIniWriteMosque(IniFile, "Mosques", name, mosqueName)
        }

        ; Print automatically without confirmation
        PrintExcelFile(outputFile, printArea)

        ; Update status bar
        gui.StatusBar := "✅ Generated and printed: " safeName

    } catch as err {
        try xlApp.Quit()
        MsgBox "Error saving file:`n" err.Message, "Error", 16 + 0x40000
        return
    }

    ; Save ID to INI
    UnicodeIniWrite(IniFile, "People", name, id)

    ; Update combobox
    cbName := gui["Name"]
    listArr := LoadNamesFromIni()
    if (listArr.Length) {
        cbName.Delete()
        cbName.Add(listArr)
        cbName.Text := name
    }
}

; Load names from INI
NamesList := LoadNamesFromIni()

; ============== GUI LAYOUT ==============
mainGui := Gui("+AlwaysOnTop", "MTO")
mainGui.SetFont("s10", "Segoe UI")
mainGui.SetFont("s11 bold", "Segoe UI")
mainGui.BackColor := "F0F0F0"

mainGui.SetFont("s13 bold c1E3A8F", "Segoe UI")
mainGui.Add("Text", "x15 y15 w400", "📊 Miskidhe Masakkathi Sheet Generator")
mainGui.SetFont("s9 c666666", "Segoe UI")
mainGui.Add("Text", "x15 y40 w400", "Generate and print attendance sheets, OT sheets, and contract sheets.")
mainGui.Add("Text", "x15 y55 w420 h1 BackgroundD3D3D3", "")

mainGui.SetFont("s10", "Segoe UI")
mainGui.Add("Text", "x15 y75 w100", "📄 Sheet Type:")
mainGui.SetFont("s11", "Segoe UI")
cbSheetType := mainGui.Add("ComboBox", "x120 y70 w350 vSheetType", ["Wage Attendance Sheet", "OT Sheet",
    "Contract Miskithu Attendance"])
cbSheetType.Text := "Wage Attendance Sheet"
cbSheetType.OnEvent("Change", SheetTypeChanged)
mainGui.SetFont("s10", "Segoe UI")

mainGui.Add("Text", "x15 y115 w100", "👤 Name:")
mainGui.SetFont("s11", "Segoe UI")
cbName := mainGui.Add("ComboBox", "x120 y110 w350 vName", NamesList)
mainGui.SetFont("s10", "Segoe UI")

mainGui.Add("Text", "x15 y155 w100", "🆔 ID Card #:")
mainGui.SetFont("s11", "Segoe UI")
edID := mainGui.Add("Edit", "x120 y150 w350 vID")
mainGui.SetFont("s10", "Segoe UI")

mainGui.Add("Text", "x15 y195 w100", "🕌 Mosque:")
mainGui.SetFont("s11", "Segoe UI")
edMosque := mainGui.Add("Edit", "x120 y190 w350 vMosque")
mainGui.SetFont("s10", "Segoe UI")

grpDates := mainGui.Add("GroupBox", "x10 y235 w475 h110", "📅 Date Range")
mainGui.Add("Text", "x25 y265 w90", "📅 From:")
dtStart := mainGui.Add("DateTime", "x120 y260 w350 vStart1", "yyyy-MM-dd")
mainGui.Add("Text", "x25 y300 w90", "📅 To:")
dtEnd := mainGui.Add("DateTime", "x120 y295 w350 vEnd1", "yyyy-MM-dd")

SetDateTimeValue(dtStart, GetStartDateDefault())
SetDateTimeValue(dtEnd, GetEndDateDefault())

btnGeneratePrint := mainGui.Add("Button", "x120 y368 w230 h40 Default", "✨ Generate & Print")
btnCancel := mainGui.Add("Button", "x360 y368 w120 h40", "❌ Cancel")

try btnGeneratePrint.Opt("+Background2E7D32 +cWhite")
try btnCancel.Opt("+Background757575 +cWhite")

mainGui.StatusBar := "✅ Ready"
mainGui.dtStart := dtStart
mainGui.dtEnd := dtEnd
mainGui.grpDates := grpDates
mainGui.edMosque := edMosque
mainGui.btnGeneratePrint := btnGeneratePrint
mainGui.btnCancel := btnCancel
mainGui.MinSize := "500|460"

cbName.OnEvent("Change", NameChanged)
btnGeneratePrint.OnEvent("Click", GenerateAndPrint)
btnCancel.OnEvent("Click", (*) => ExitApp())
mainGui.OnEvent("Close", (*) => ExitApp())
mainGui.OnEvent("Escape", (*) => ExitApp())

mainGui.Show()
return

SheetTypeChanged(ctrl, info) {
    gui := ctrl.Gui
    sheetType := ctrl.Text
    if (sheetType = "Contract Miskithu Attendance") {
        gui.edMosque.Enabled := true
        gui.edMosque.Opt("-ReadOnly")
    } else {
        gui.edMosque.Enabled := false
        gui.edMosque.Opt("+ReadOnly")
    }
    if (sheetType = "OT Sheet") {
        gui.grpDates.Enabled := false
        gui.dtStart.Enabled := false
        gui.dtEnd.Enabled := false
        gui.dtStart.Opt("+ReadOnly")
        gui.dtEnd.Opt("+ReadOnly")
    } else {
        gui.grpDates.Enabled := true
        gui.dtStart.Enabled := true
        gui.dtEnd.Enabled := true
        gui.dtStart.Opt("-ReadOnly")
        gui.dtEnd.Opt("-ReadOnly")
    }
}

GetDateString(gui, controlVar) {
    ctrl := gui[controlVar]
    dateText := ctrl.Text
    if RegExMatch(dateText, "^(\d{4})-(\d{2})-(\d{2})$", &match)
        return match[1] "-" match[2] "-" match[3]
    if RegExMatch(dateText, "(\d{1,2})[/-](\d{1,2})[/-](\d{4})", &match)
        return match[3] "-" match[2] "-" match[1]
    return dateText
}

NameChanged(ctrl, info) {
    global IniFile
    name := ctrl.Text
    if (name = "")
        return
    id := UnicodeIniRead(IniFile, "People", name, "")
    if (id != "") {
        gui := ctrl.Gui
        edID := gui["ID"]
        edID.Text := id
    }
    mosqueName := LoadMosqueFromIni(name)
    if (mosqueName != "") {
        gui := ctrl.Gui
        edMosque := gui["Mosque"]
        if (edMosque)
            edMosque.Text := mosqueName
    }
}
